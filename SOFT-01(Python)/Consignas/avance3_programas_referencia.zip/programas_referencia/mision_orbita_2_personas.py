# ============================================================
# Archivo: mision_orbita.py
# Curso: SOFT-01 Principios de Programación 1 - Sección SCV6
# Integrantes: Solución de referencia (docente)
# Fecha: 21/10/2026        Versión: 1.0
# Descripción: Sistema integrado Misión Órbita (preparación, viaje,
#              exploración, regreso, reporte e historial).
# ============================================================
TAMANO_GRUPO = 2   # solo en la referencia: 1, 2 o 3 integrantes

# ---------- Constantes ----------
DESTINOS = (("Luna", 3), ("Marte", 5), ("Europa", 7))
# (nombre, combustible, energía, provisiones, puntos)
ACTIVIDADES = (("Analizar terreno", 0, 8, 0, 10),
               ("Recolectar muestra", 0, 12, 2, 20),
               ("Realizar observación", 0, 5, 0, 8),
               ("Sobrevolar la zona", 15, 3, 0, 25))
RECURSOS = ("combustible", "oxígeno", "energía", "provisiones")
RESULTADOS = ("Regreso exitoso", "Regreso interrumpido", "Tripulación varada",
              "No autorizada", "No planificada")
CONSUMO_COMBUSTIBLE_DIA = 8
CONSUMO_OXIGENO_DIA = 2          # por tripulante
CONSUMO_ENERGIA_DIA = 5
CONSUMO_PROVISIONES_DIA = 1      # por tripulante
TRAYECTOS = 2
RESERVA_COMBUSTIBLE = 10
OXIGENO_EMERGENCIA = 5
ENERGIA_EXPLORACION = 10
PROVISIONES_ADICIONALES = 3
MARGEN_MINIMO = 10
ACTIVIDAD_MUESTRA = "Recolectar muestra"


# ---------- A. Preparación y autorización ----------
def mostrar_destinos():
    """Muestra los destinos de la tupla DESTINOS."""
    print("Destinos disponibles:")
    numero = 1
    for destino in DESTINOS:
        nombre, dias = destino
        print(str(numero) + ". " + nombre + " (" + str(dias) + " días)")
        numero = numero + 1


def leer_recursos():
    """Lee los cuatro recursos disponibles y los devuelve en un diccionario."""
    recursos = {}
    for recurso in RECURSOS:
        recursos[recurso] = int(input("Cantidad disponible de " + recurso + ": "))
    return recursos


def calcular_requeridos(dias_viaje, tripulantes):
    """Devuelve un diccionario con los recursos requeridos (fórmulas del Avance 1)."""
    requeridos = {}
    requeridos["combustible"] = dias_viaje * CONSUMO_COMBUSTIBLE_DIA * TRAYECTOS + RESERVA_COMBUSTIBLE
    requeridos["oxígeno"] = dias_viaje * CONSUMO_OXIGENO_DIA * TRAYECTOS * tripulantes + OXIGENO_EMERGENCIA
    requeridos["energía"] = dias_viaje * CONSUMO_ENERGIA_DIA * TRAYECTOS + ENERGIA_EXPLORACION
    requeridos["provisiones"] = dias_viaje * tripulantes * CONSUMO_PROVISIONES_DIA * TRAYECTOS + PROVISIONES_ADICIONALES
    return requeridos


def mostrar_resumen(nombre_mision, nombre_destino, dias_viaje, tripulantes, disponibles, requeridos):
    """Muestra el resumen de planificación de la misión."""
    print()
    print("Misión:", nombre_mision)
    print("Destino:", nombre_destino)
    print("Duración del viaje de ida:", dias_viaje, "días")
    print("Tripulantes:", tripulantes)
    for recurso in RECURSOS:
        print(recurso.capitalize() + ": disponible " + str(disponibles[recurso])
              + " | requerido " + str(requeridos[recurso]))
    margen = disponibles["combustible"] - requeridos["combustible"]
    print("Margen adicional de combustible:", margen, "unidades")
    if margen < MARGEN_MINIMO:
        print("Advertencia: el margen adicional de combustible es bajo.")


def autorizar_lanzamiento(disponibles, requeridos):
    """Devuelve True si los cuatro recursos disponibles cubren lo requerido."""
    autorizado = True
    for recurso in RECURSOS:
        if disponibles[recurso] < requeridos[recurso]:
            autorizado = False
    return autorizado


# ---------- B. Viaje ----------
def calcular_consumo_diario(tripulantes):
    consumo = {}
    consumo["combustible"] = CONSUMO_COMBUSTIBLE_DIA
    consumo["oxígeno"] = CONSUMO_OXIGENO_DIA * tripulantes
    consumo["energía"] = CONSUMO_ENERGIA_DIA
    consumo["provisiones"] = CONSUMO_PROVISIONES_DIA * tripulantes
    return consumo


def viajar_al_destino(recursos, dias_viaje, tripulantes):
    consumo = calcular_consumo_diario(tripulantes)
    for recurso in RECURSOS:
        recursos[recurso] = recursos[recurso] - consumo[recurso] * dias_viaje
    return recursos


def recursos_alcanzan(recursos, consumo):
    alcanzan = True
    for recurso in RECURSOS:
        if recursos[recurso] < consumo[recurso]:
            alcanzan = False
    return alcanzan


def simular_trayecto(recursos, dias, tripulantes):
    consumo = calcular_consumo_diario(tripulantes)
    dias_completados = 0
    puede_continuar = True
    while dias_completados < dias and puede_continuar:
        if recursos_alcanzan(recursos, consumo):
            for recurso in RECURSOS:
                recursos[recurso] = recursos[recurso] - consumo[recurso]
            dias_completados = dias_completados + 1
            linea = "Día " + str(dias_completados)
            for recurso in RECURSOS:
                linea = linea + " | " + recurso.capitalize() + ": " + str(recursos[recurso])
            print(linea)
        else:
            puede_continuar = False
    return dias_completados


def mostrar_recursos(recursos):
    print("Recursos restantes:")
    for recurso in RECURSOS:
        print("- " + recurso.capitalize() + ": " + str(recursos[recurso]) + " unidades")


# ---------- C. Exploración ----------
def mostrar_menu_actividades():
    numero = 1
    for actividad in ACTIVIDADES:
        print(str(numero) + ". " + actividad[0])
        numero = numero + 1
    print(str(numero) + ". Finalizar exploración")


def explorar(recursos):
    bitacora = []
    opcion_finalizar = len(ACTIVIDADES) + 1
    explorando = True
    while explorando:
        print()
        mostrar_menu_actividades()
        opcion = int(input("Seleccione una actividad: "))
        if opcion >= 1 and opcion <= len(ACTIVIDADES):
            nombre, combustible, energia, provisiones, puntos = ACTIVIDADES[opcion - 1]
            if (recursos["combustible"] >= combustible and recursos["energía"] >= energia
                    and recursos["provisiones"] >= provisiones):
                recursos["combustible"] = recursos["combustible"] - combustible
                recursos["energía"] = recursos["energía"] - energia
                recursos["provisiones"] = recursos["provisiones"] - provisiones
                registro = {"numero": len(bitacora) + 1, "actividad": nombre, "puntos": puntos}
                bitacora.append(registro)
                print("Actividad realizada: " + nombre + ". Puntos obtenidos: " + str(puntos))
            else:
                print("Recursos insuficientes para realizar la actividad. La exploración finaliza.")
                explorando = False
        elif opcion == opcion_finalizar:
            print("Exploración finalizada por la tripulación.")
            explorando = False
        else:
            print("Opción no válida.")
    return bitacora


def contar_actividad(bitacora, nombre_actividad):
    cantidad = 0
    for registro in bitacora:
        if registro["actividad"] == nombre_actividad:
            cantidad = cantidad + 1
    return cantidad


def calcular_puntos(bitacora):
    total = 0
    for registro in bitacora:
        total = total + registro["puntos"]
    return total


def mostrar_resumen_exploracion(bitacora, recursos):
    print()
    print("Actividades realizadas:", len(bitacora))
    print("Muestras recolectadas:", contar_actividad(bitacora, ACTIVIDAD_MUESTRA))
    print("Puntos científicos:", calcular_puntos(bitacora))
    mostrar_recursos(recursos)


# ---------- D. Regreso y supervivencia ----------
def puede_regresar(recursos, dias_viaje):
    return recursos["combustible"] >= dias_viaje * CONSUMO_COMBUSTIBLE_DIA


def calcular_supervivencia(recursos, tripulantes):
    dias_por_recurso = {}
    dias_por_recurso["oxígeno"] = recursos["oxígeno"] // (tripulantes * CONSUMO_OXIGENO_DIA)
    dias_por_recurso["energía"] = recursos["energía"] // CONSUMO_ENERGIA_DIA
    dias_por_recurso["provisiones"] = recursos["provisiones"] // (tripulantes * CONSUMO_PROVISIONES_DIA)
    return dias_por_recurso


def buscar_minimo(dias_por_recurso):
    minimo = dias_por_recurso["oxígeno"]
    for recurso in dias_por_recurso:
        if dias_por_recurso[recurso] < minimo:
            minimo = dias_por_recurso[recurso]
    return minimo


def buscar_limitantes(dias_por_recurso, minimo):
    limitantes = []
    for recurso in dias_por_recurso:
        if dias_por_recurso[recurso] == minimo:
            limitantes.append(recurso)
    return limitantes


def regresar(recursos, dias_viaje, tripulantes):
    if puede_regresar(recursos, dias_viaje):
        dias_completados = simular_trayecto(recursos, dias_viaje, tripulantes)
        if dias_completados == dias_viaje:
            print("La tripulación regresó exitosamente a la Tierra.")
            mostrar_recursos(recursos)
            resultado = "Regreso exitoso"
        else:
            print("El regreso se interrumpió en el día " + str(dias_completados + 1) + ".")
            consumo = calcular_consumo_diario(tripulantes)
            for recurso in RECURSOS:
                if recursos[recurso] < consumo[recurso]:
                    print("Recurso insuficiente:", recurso)
            print("La tripulación no completó el regreso.")
            resultado = "Regreso interrumpido"
    else:
        print("La tripulación quedó varada en el destino.")
        dias_por_recurso = calcular_supervivencia(recursos, tripulantes)
        for recurso in dias_por_recurso:
            print("Días por " + recurso + ": " + str(dias_por_recurso[recurso]))
        minimo = buscar_minimo(dias_por_recurso)
        limitantes = buscar_limitantes(dias_por_recurso, minimo)
        print("Supervivencia estimada:", minimo, "días")
        print("Recurso(s) limitante(s): " + ", ".join(limitantes))
        resultado = "Tripulación varada"
    return resultado


# ---------- E. Reporte final ----------
def ordenar_bitacora(bitacora):
    ordenada = []
    for elemento in bitacora:
        ordenada.append(elemento)
    for i in range(len(ordenada) - 1):
        for j in range(len(ordenada) - 1 - i):
            if (ordenada[j]["puntos"] < ordenada[j + 1]["puntos"]
                    or (ordenada[j]["puntos"] == ordenada[j + 1]["puntos"]
                        and ordenada[j]["numero"] > ordenada[j + 1]["numero"])):
                temporal = ordenada[j]
                ordenada[j] = ordenada[j + 1]
                ordenada[j + 1] = temporal
    return ordenada


def mostrar_reporte(mision, bitacora):
    print()
    print("=== REPORTE FINAL ===")
    print("Misión:", mision["nombre"])
    print("Destino:", mision["destino"])
    print("Resultado:", mision["resultado"])
    print("Puntos científicos:", mision["puntos"])
    print("Bitácora de exploración (de mayor a menor puntaje):")
    if len(bitacora) == 0:
        print("Sin actividades registradas.")
    else:
        for registro in ordenar_bitacora(bitacora):
            print("#" + str(registro["numero"]) + " " + registro["actividad"] + " - "
                  + str(registro["puntos"]) + " puntos")


def ejecutar_mision(numero):
    print()
    print("=== PLANIFICACIÓN ===")
    nombre_mision = input("Nombre de la misión: ")
    tripulantes = int(input("Cantidad de tripulantes: "))
    mostrar_destinos()
    opcion = int(input("Seleccione un destino: "))
    nombre_destino = "Ninguno"
    puntos = 0
    bitacora = []
    if opcion < 1 or opcion > len(DESTINOS):
        print("Opción de destino no válida. La misión no puede planificarse.")
        resultado = "No planificada"
    else:
        nombre_destino, dias_viaje = DESTINOS[opcion - 1]
        recursos = leer_recursos()
        requeridos = calcular_requeridos(dias_viaje, tripulantes)
        mostrar_resumen(nombre_mision, nombre_destino, dias_viaje, tripulantes, recursos, requeridos)
        if autorizar_lanzamiento(recursos, requeridos):
            print("Lanzamiento autorizado.")
            print()
            print("=== VIAJE DE IDA ===")
            if TAMANO_GRUPO == 3:
                simular_trayecto(recursos, dias_viaje, tripulantes)
            else:
                viajar_al_destino(recursos, dias_viaje, tripulantes)
            print("La nave llegó a " + nombre_destino + " en " + str(dias_viaje) + " días.")
            mostrar_recursos(recursos)
            print()
            print("=== EXPLORACIÓN ===")
            bitacora = explorar(recursos)
            mostrar_resumen_exploracion(bitacora, recursos)
            puntos = calcular_puntos(bitacora)
            print()
            print("=== REGRESO ===")
            resultado = regresar(recursos, dias_viaje, tripulantes)
        else:
            print("Lanzamiento no autorizado. La misión debe ser revisada.")
            resultado = "No autorizada"
    mision = {"numero": numero, "nombre": nombre_mision, "destino": nombre_destino,
              "resultado": resultado, "puntos": puntos}
    mostrar_reporte(mision, bitacora)
    return mision


# ---------- F, G, H. Historial (2 y 3 personas) ----------
def ordenar_historial(historial):
    ordenada = []
    for elemento in historial:
        ordenada.append(elemento)
    for i in range(len(ordenada) - 1):
        for j in range(len(ordenada) - 1 - i):
            if (ordenada[j]["puntos"] < ordenada[j + 1]["puntos"]
                    or (ordenada[j]["puntos"] == ordenada[j + 1]["puntos"]
                        and ordenada[j]["numero"] > ordenada[j + 1]["numero"])):
                temporal = ordenada[j]
                ordenada[j] = ordenada[j + 1]
                ordenada[j + 1] = temporal
    return ordenada


def linea_mision(mision):
    return ("#" + str(mision["numero"]) + " " + mision["nombre"] + " | " + mision["destino"]
            + " | " + mision["resultado"] + " | " + str(mision["puntos"]) + " puntos")


def mostrar_historial(historial):
    print()
    print("=== HISTORIAL DE MISIONES ===")
    if len(historial) == 0:
        print("No hay misiones registradas.")
    else:
        for mision in ordenar_historial(historial):
            print(linea_mision(mision))


def buscar_misiones(historial, nombre_buscado):
    encontradas = []
    for mision in historial:
        if mision["nombre"] == nombre_buscado:
            encontradas.append(mision)
    return encontradas


def mostrar_busqueda(historial):
    print()
    nombre_buscado = input("Nombre de la misión a buscar: ")
    encontradas = buscar_misiones(historial, nombre_buscado)
    if len(encontradas) == 0:
        print("No se encontró ninguna misión con el nombre: " + nombre_buscado)
    else:
        print("Misiones encontradas:", len(encontradas))
        for mision in encontradas:
            print(linea_mision(mision))


def mostrar_estadisticas(historial):
    print()
    print("=== ESTADÍSTICAS ===")
    if len(historial) == 0:
        print("No hay misiones registradas.")
    else:
        print("Total de misiones:", len(historial))
        for resultado in RESULTADOS:
            cantidad = 0
            for mision in historial:
                if mision["resultado"] == resultado:
                    cantidad = cantidad + 1
            print(resultado + ": " + str(cantidad))
        total_puntos = 0
        mejor = historial[0]
        for mision in historial:
            total_puntos = total_puntos + mision["puntos"]
            if (mision["puntos"] > mejor["puntos"]
                    or (mision["puntos"] == mejor["puntos"] and mision["numero"] < mejor["numero"])):
                mejor = mision
        print("Promedio de puntos:", round(total_puntos / len(historial), 2))
        print("Misión con más puntos: #" + str(mejor["numero"]) + " " + mejor["nombre"]
              + " (" + str(mejor["puntos"]) + " puntos)")


def mostrar_menu_principal():
    print()
    print("===== MISIÓN ÓRBITA =====")
    print("1. Planificar y ejecutar una misión")
    print("2. Ver historial de misiones")
    if TAMANO_GRUPO == 3:
        print("3. Buscar misión por nombre")
        print("4. Ver estadísticas")
        print("5. Salir")
    else:
        print("3. Salir")


def main():
    if TAMANO_GRUPO == 1:
        print("===== MISIÓN ÓRBITA =====")
        ejecutar_mision(1)
    else:
        historial = []
        opcion_salir = 3
        if TAMANO_GRUPO == 3:
            opcion_salir = 5
        activo = True
        while activo:
            mostrar_menu_principal()
            opcion = int(input("Seleccione una opción: "))
            if opcion == 1:
                mision = ejecutar_mision(len(historial) + 1)
                historial.append(mision)
            elif opcion == 2:
                mostrar_historial(historial)
            elif TAMANO_GRUPO == 3 and opcion == 3:
                mostrar_busqueda(historial)
            elif TAMANO_GRUPO == 3 and opcion == 4:
                mostrar_estadisticas(historial)
            elif opcion == opcion_salir:
                activo = False
            else:
                print("Opción no válida.")
    print()
    print("Fin del sistema Misión Órbita.")


main()
